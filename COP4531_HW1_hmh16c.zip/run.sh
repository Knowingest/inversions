#!/usr/bin/env bash
echo NOTE: Estimated time for Sample6 is 5.5 minutes
echo running...
inversionCounter.exe $1
